
<button class="btn d-sm-none" data-bs-toggle="collapse" data-bs-target="#side">
    <i class="fa-solid fa-bars"></i><b>Menu</b>
</button>

<div class="collapse d-sm-block"id="side">
    <div class="profile">
                <img class=" img-fluid profile-img"src="<?php
        if(isset($_SESSION['pic'])){
            echo $_SESSION['pic'];
           
        }
    ?>" alt="">
                </div>
                <ul>
                    <li><a href="dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a></li>
                     <li>
                        <a href="#Expense" data-bs-toggle="collapse"><i class="fa-solid fa-bars"></i>
                             Expenses
                        </a>

                        <ul class="collapse" id="Expense">
                            <li><a href="Add_expense.php"><i class="fa-solid fa-arrow-right"></i> Add Expense</a></li>
                            <li><a href="Manage_expense.php"><i class="fa-solid fa-arrow-right"></i> Manage Expense</a></li>
                           
                        </ul>
                    </li>

                    <li>
                        <a href="#report" data-bs-toggle="collapse"><i class="fa-solid fa-bars"></i>
                             Expense Report
                        </a>

                        <ul class="collapse" id="report">
                            <li><a href="Daywise_report.php"><i class="fa-solid fa-arrow-right"></i> Daywise Report</a></li>
                            <li><a href="Monthwise_report.php"><i class="fa-solid fa-arrow-right"></i> Monthwise Report</a></li>
                            <li><a href="Yearwise_expense.php"><i class="fa-solid fa-arrow-right"></i> Yearwise Report</a></li>
                        </ul>
                    </li>
                     <li><a href="profile.php"><i class="fa-solid fa-user"></i> Profile</a></li>
                      <li><a href="uploadpic.php"><i class="fa-solid fa-camera"></i> Upload Profile pic</a></li> 
                      <li><a href="changepassword.php"><i class="fa-solid fa-file-pen"></i> Change password</a></li> 
                      <li><a href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a></li>

                </ul>

</div>

