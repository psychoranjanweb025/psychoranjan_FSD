<?php
session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>upload pic</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"type="text/css" href="expencestyle.css">
</head>

<body>
    <header class="container-fluid banner">

        <div class="row">
            <div class="col-sm-12 py-3">
              <?php include 'header.php'  ?>
            </div>

        </div>
    </header>
    <section class="container-fluid">

        <div class="row justify-content-center">
            

            <div class="col-sm-2 menu">
              <?php include 'sidebar.php'  ?> 
            </div>
            <div class="col-sm-10 content">
                <div class="container maincontent">
                    <form method="post" enctype="multipart/form-data">
                        <input type="file" name="txtfile" accept="image/jpeg,image/png"required><br>
                        <input type="submit" class="btn btn1" value="Upload" name="btnupload">
                    </form>
               <?php
                    if(isset($_POST['btnupload'])){
                        if($_FILES['txtfile']['error'] == 0 ){
                            if($_FILES['txtfile']['type']=='image/jpeg' || $_FILES['txtfile']['type']=='image/png'){
                                    $from = $_FILES['txtfile']['tmp_name'];
                                    $to = $_SERVER['DOCUMENT_ROOT']."/PROJECT/picture/".$_FILES['txtfile']['name'];
                                    if(move_uploaded_file($from, $to)){
                                        $_SESSION['pic'] = "picture/".$_FILES['txtfile']['name'];
                                        echo "<p class='text-success'>Picture Uploaded</p>";
                                    }
                                    else
                                        echo "<p class='text-danger'>Error in uploading the file</p>";
                            }
                            else
                                echo "<p class='text-danger'>Invalid file format (Use jpeg, png type)</p>";
                        }
                        else{
                            echo "<p class='text-danger'>File is cruptted</p>";
                        }
                    }
                ?>

                 </div>
            </div>

        </div>
    </section>
    <footer class="container-fluid foot">
       <?php include 'footer.php'  ?>
    </footer>

</body>

</html>