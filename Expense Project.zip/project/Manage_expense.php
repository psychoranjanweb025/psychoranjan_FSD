<?php
session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage expenset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"type="text/css" href="expencestyle.css">
</head>

<body>
    <header class="container-fluid banner">

        <div class="row">
            <div class="col-sm-12 py-3">
              <?php include 'header.php'  ?>
            </div>

        </div>
    </header>
    <section class="container-fluid">

        <div class="row justify-content-center">
            

            <div class="col-sm-2 menu">
              <?php include 'sidebar.php'  ?> 
            </div>
            <div class="col-sm-10 content">

            <div class="table-responsive mainconten table-striped table-borderedt">
                <table class="table table1">
                    <tr class="title">
                        <td  colspan="3"><h2>Expense Detail's</h2></td>
                    </tr>
                     <tr class="heading">
                        <th>Expense Date</th>
                        <th>Categories</th>
                        <th>Expense Item Name</th>
                        <th>Expense Amount Name</th>
                        <th>Action</th>
                    </tr>
                    
                            <?php
        $con = mysqli_connect("localhost","root","","dets_db");
        $uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;

        $qry = "SELECT * FROM tblexpense
                WHERE userid = $uid
                ORDER BY expensedate DESC";

        $result = mysqli_query($con,$qry);

        while($row=mysqli_fetch_array($result))
        {
            echo "<tr>";
            echo "<td>".$row[2]."</td>";
            echo "<td>".$row[3]."</td>";
            echo "<td>".$row[4]."</td>";
            echo "<td>".$row[5]."</td>";
            echo "<td><a href='Delete.php?id=".$row[0]."' class='btn btn-danger btn-sm'>Delete</a></td>";
            echo "</tr>";
        }

        mysqli_close($con);
        ?>
                </table>

            </div>
            </div>

        </div>
    </section>
    <footer class="container-fluid foot">
       <?php include 'footer.php'  ?>
    </footer>

</body>

</html>