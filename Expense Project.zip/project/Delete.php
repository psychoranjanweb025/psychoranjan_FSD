<?php
session_start();

if(!isset($_SESSION['name'])){
    header("location:login.php");
    exit();
}

$id = isset($_REQUEST['id']) ? (int)$_REQUEST['id'] : 0;
$uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;

if($id > 0 && $uid > 0){
    $con = mysqli_connect("localhost", "root", "", "dets_db");
    $qry = "DELETE FROM tblexpense WHERE ID = $id AND UserId = $uid";
    mysqli_query($con, $qry);
    mysqli_close($con);
}

header("location:Manage_expense.php");
exit();
?>